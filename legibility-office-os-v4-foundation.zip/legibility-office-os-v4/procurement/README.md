# Procurement

Application domain for procurement as strategic infrastructure.
