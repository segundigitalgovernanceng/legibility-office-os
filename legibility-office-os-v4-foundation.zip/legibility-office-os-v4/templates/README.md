# Templates

Reusable implementation templates for practitioners.

Planned:

- policy-template.md
- governance-template.md
- procurement-template.md
- institution-template.md
