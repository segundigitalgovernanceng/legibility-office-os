# v4 Build Roadmap

## Phase 1 — Foundation
- [x] Canonical schemas
- [x] Signal registry structure
- [x] Institutional entity structure
- [x] Relationship structure
- [x] Research asset structure
- [x] Initial validation tool
- [x] Initial classifier
- [x] Forecast ledger

## Phase 2 — Memory
- [ ] Country profiles
- [ ] Institutional state profiles
- [ ] Pattern records
- [ ] Historical signal ingestion
- [ ] Evidence provenance model

## Phase 3 — Intelligence
- [ ] Capability scoring
- [ ] Dependency mapping
- [ ] Relationship intelligence
- [ ] Forecast calibration
- [ ] Cross-country comparison

## Phase 4 — Automation
- [ ] Signal ingestion pipeline
- [ ] Policy parser
- [ ] Governance classifier
- [ ] Knowledge-graph updater
- [ ] IOS validator

## Phase 5 — Research Infrastructure
- [ ] Research hypothesis engine
- [ ] Evidence graph
- [ ] Publication escalation
- [ ] Dataset registry
