# Governance

Application domain for governance architecture and primitives.
