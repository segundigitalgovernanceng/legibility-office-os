# Research Engine

Research is downstream from signals, not separate from them.

Pipeline:

Signal → Observation → Hypothesis → Research Question → Dataset → Paper → Framework → Tool

Every research asset should retain links to the signals and evidence that generated it.
