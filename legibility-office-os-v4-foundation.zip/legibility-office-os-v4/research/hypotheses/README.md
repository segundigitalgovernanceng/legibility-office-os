# Hypotheses

Store testable institutional hypotheses.

Each hypothesis should link to supporting and contradictory signals.
