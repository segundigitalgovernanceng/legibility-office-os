# Evidence

Store evidence records, excerpts, source metadata, and evidence assessments.

Separate verified evidence from model inference.
