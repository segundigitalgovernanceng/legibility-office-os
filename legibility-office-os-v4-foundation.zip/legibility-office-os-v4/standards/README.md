# Standards

Institutional, procurement, and governance standards.
