# Legibility Office Institutional Signal Intelligence System v4.0

The open-source reference architecture for institutional signal intelligence.

## Core thesis

Legibility Office does not treat public announcements as the final object of analysis.

It treats each announcement, policy, procurement action, infrastructure programme, institutional change, or technology deployment as a **signal of deeper institutional evolution**.

The system converts:

**Signal → Architecture → Capability → Dependency → Execution → Outcome → Memory → Foresight**

## Five foundations

1. `schemas/` — canonical data structures
2. `knowledge-graph/` — entities, relationships, signals, patterns, ontology
3. `datasets/` — institutional and signal records
4. `tools/` — validation, classification, scoring, graph utilities
5. `research/` — hypotheses, evidence, references, datasets

Existing domain folders become applications of the intelligence architecture:

- `governance/`
- `procurement/`
- `dpi/`
- `ai-governance/`
- `standards/`
- `publications/`

## Design principle

> Build the memory before the empire.

Every new signal should increase the value of the signals already collected.
