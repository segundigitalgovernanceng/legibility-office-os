# Changelog

## 4.0.0 — 2026-08-08

The architecture moves from a publication-oriented signal pipeline toward a compounding institutional intelligence system.

Added:

- canonical schemas
- institutional knowledge graph structure
- signal registry
- capability matrix
- forecast ledger
- research asset architecture
- validation tooling
- deterministic first-pass classifier
- institutional memory architecture
