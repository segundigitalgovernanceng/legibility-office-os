# Relationships

Store explicit relationships between entities.

Example:

`institution-nigeria-ministry-x` → `depends_on` → `dpi-national-id`

Attach confidence and evidence whenever possible.
