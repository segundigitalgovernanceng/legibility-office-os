# Patterns

Patterns are recurring structures discovered across multiple signals.

A pattern should reference:

- supporting signals
- countries
- institutions
- capability layers
- governance primitives
- confidence
- first observed date
- latest observed date
