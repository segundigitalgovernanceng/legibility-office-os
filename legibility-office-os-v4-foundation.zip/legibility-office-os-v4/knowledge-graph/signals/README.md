# Signals

Each important institutional signal receives a stable identifier.

Recommended pattern:

`SIG-YYYY-NNNN`

The signal record should conform to `schemas/signal.schema.json`.
