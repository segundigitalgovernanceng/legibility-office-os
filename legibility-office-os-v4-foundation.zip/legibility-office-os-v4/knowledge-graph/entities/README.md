# Entities

Store one canonical JSON record per important institution, country, framework, technology, capability, or other entity.

Naming convention:

`<entity-type>-<stable-slug>.json`
