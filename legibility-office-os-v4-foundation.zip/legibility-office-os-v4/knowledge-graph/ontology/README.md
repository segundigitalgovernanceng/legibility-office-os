# Institutional Ontology

Canonical entity types:

- Institution
- Country
- Signal
- Policy
- GovernancePrimitive
- Capability
- ProcurementSystem
- DPI
- Technology
- Dependency
- Risk
- Framework
- ResearchAsset
- Relationship
- Outcome
- CivilizationTheme

Canonical relationship examples:

- `governs`
- `coordinates_with`
- `procures`
- `depends_on`
- `implements`
- `regulates`
- `develops_capability`
- `produces`
- `influences`
- `constrained_by`
- `evidences`
- `reinforces`
