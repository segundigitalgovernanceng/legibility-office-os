from dataclasses import dataclass

@dataclass
class SignalClassification:
    category: str
    strategic_importance: str

def classify(signal: dict) -> SignalClassification:
    text = " ".join(str(signal.get(k, "")) for k in [
        "signal_type", "policy_domain", "execution_constraints"
    ]).lower()

    if any(x in text for x in ["legislation", "law", "regulation"]):
        return SignalClassification("structural", "high")
    if any(x in text for x in ["procurement", "contract", "tender"]):
        return SignalClassification("operational", "high")
    if any(x in text for x in ["strategy", "national plan", "framework"]):
        return SignalClassification("strategic", "high")
    return SignalClassification("routine", "medium")
