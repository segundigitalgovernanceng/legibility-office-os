import json
from pathlib import Path

def load_relationships(path):
    return json.loads(Path(path).read_text())

def neighbors(relationships, node):
    return [
        r for r in relationships
        if r.get("source") == node or r.get("target") == node
    ]
