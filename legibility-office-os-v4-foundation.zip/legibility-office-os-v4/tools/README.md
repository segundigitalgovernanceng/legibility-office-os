# Tools

Initial tool layer:

- `validate_signal.py` — validate signal records against the canonical schema
- `classify_signal.py` — deterministic first-pass signal classification
- `graph_utils.py` — lightweight graph loading and relationship inspection

The tool layer should remain modular so later implementations can be replaced without changing the ontology.
