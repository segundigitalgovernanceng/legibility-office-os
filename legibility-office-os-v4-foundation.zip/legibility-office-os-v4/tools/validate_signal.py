import json
from pathlib import Path
import sys

try:
    from jsonschema import validate
except ImportError:
    validate = None

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = json.loads((ROOT / "schemas/signal.schema.json").read_text())

def main(path: str):
    record = json.loads(Path(path).read_text())
    if validate is None:
        print("jsonschema is not installed; performing basic validation.")
        required = SCHEMA["required"]
        missing = [k for k in required if k not in record]
        if missing:
            raise SystemExit(f"Missing required fields: {missing}")
    else:
        validate(instance=record, schema=SCHEMA)
    print("VALID:", path)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python tools/validate_signal.py <signal.json>")
    main(sys.argv[1])
