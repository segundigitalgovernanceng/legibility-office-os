# Digital Public Infrastructure

Application domain for identity, payments, data exchange, and interoperability.
