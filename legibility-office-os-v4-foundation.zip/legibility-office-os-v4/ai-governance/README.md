# AI Governance

Application domain for AI governance, public-sector AI, and procurement for AI.
